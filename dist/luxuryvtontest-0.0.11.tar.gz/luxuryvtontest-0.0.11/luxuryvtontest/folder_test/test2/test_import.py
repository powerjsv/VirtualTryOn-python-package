def testimport():
    print("This is test for another directory import")
