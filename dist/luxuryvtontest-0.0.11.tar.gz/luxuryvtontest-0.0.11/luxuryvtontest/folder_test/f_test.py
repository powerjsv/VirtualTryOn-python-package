from .test2 import test_import
def f_testprint():
    print("This is my test function")
    test_import.testimport()
