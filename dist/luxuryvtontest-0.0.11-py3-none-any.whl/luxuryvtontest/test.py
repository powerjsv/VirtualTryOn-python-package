def testprint():
    print("This is my test function")